import re
import csv
import chemdataextractor
from chemdataextractor import Document
import pubchempy as pcp
from quantulum3 import parser
import nltk
from nltk import word_tokenize
from nltk import StanfordTagger
import pandas as pd
from bs4 import BeautifulSoup as bs
from allennlp.predictors.predictor import predictor

num_units=re.compile(r'([0-9]+ ?-?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|M|µm|g|grams|mm?|cm|%|N|molar|grits|oz|oz/f|[a-z]+ ?/ ?[a-z]+ ?[23]?))')

decnum_units=re.compile(r'([0-9]+\. ?[0-9]+ ?-?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|M|µm|g|grams|mm?|cm|%|N|molar|grits|oz|oz/f|[a-z]+ ?/ ?[a-z]+ ?[23]?))')

unit_sq=re.compile(r'([0-9]+\.?[0-9]+ ?(cm ?2|mm? ?2|[cC]entimeters? ?2|[mM]ilimeters? ?2|[mM]eters? ?2|[a-z]+ ?/ ?[a-z]+ ?[23]?|wt%|vol.%|vol%))')

plus_minus=re.compile(r'([0-9]+\.?[0-9]* ?± ?[0-9]\.?[0-9]* ?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|M|µm|g|grams|mm?|cm|%|N|molar|grits|oz|oz/f|[a-z]+ ?/ ?[a-z]+ ?[23]?) ?)')

numxnum=re.compile(r'([0-9]+\.?[0-9]* ?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|M|µm|g|grams|mm?|cm|%|N|molar|grits|oz|oz/f) ?× ?[0-9]+\.?[0-9]* ?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|M|µm|g|grams|mm|m|cm|%|N|molar|grits|oz|oz/f|[a-z]+ ?/ ?[a-z]+ ?[23]?)?)')

conditions=re.compile(r'([0-9]+\.? ?[0-9]+? ?-?(°? ?[CK]|h|hrs?|hours|min|minutes|secs?|s|°C))')



num_=re.compile(r'([0-9]+\.? ?[0-9]+? ?)')
num_units_=re.compile(r'([0-9]+\.?[0-9]* ?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|M|µm|g|grams|mm?|cm|%|N|molar|grits|oz|oz/f|[a-z]+ ?/ ?[a-z]+ ?[23]?|wt%|vol.%|vol%).?,? )')


unit_sq_=re.compile(r'([0-9]+\.?[0-9]* ?(cm ?2|mm? ?2|[cC]entimeters? ?2|[mM]ilimeters? ?2|[mM]eters? ?2|[a-z]+ ?/ ?[a-z]+ ?[23]?),?.? )')

plus_minus_=re.compile(r'([0-9]+\.?[0-9]* ?± ?[0-9]\.?[0-9]* ?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|M|µm|g|grams|mm?|cm|%|N|molar|grits|oz|oz/f|[a-z]+ ?/ ?[a-z]+ ?[23]?|wt%|vol.%|vol%),?.?)')

numxnum_=re.compile(r'([0-9]+\.?[0-9]* ?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|µm|mm?|cm)? ?× ?[0-9]+\.?[0-9]* ?(m[lL]|[Mm]ililitres?|[lL]|[lL]itres|µm|mm|m|cm|[a-z]+ ?/ ?[a-z]+ ?[23]?)?.?,?)')

conditions_=re.compile(r'([0-9]+\.?[0-9]* ?(h|hrs?|hours|mins?|minutes|secs?|s|°C|◦C|K|℃),?.?)')

conditions_plus_minus_=re.compile(r'([0-9]+ ?± ?[0-9]\.?[0-9]* ?(h|hrs?|hours|mins?|minutes|secs?|s|°C|◦C|K|℃),?.?)')



def read_files(filename):
    l=[]
    with open(filename+".txt", "r") as file:
        l=file.readlines()
    file.close()

    for i in range(len(l)):
        l[i]=l[i].replace('\n','')
    return l

processes=read_files('process_list')

for i in range(2,100):
    fnum='{0:04}'.format(i)
    try:
        with open('/sentence_wise_normalised_ip_to_tagger/sentence_ip_to_tagger_'+fnum+'.txt','r') as f:
            content=f.readlines()
        f.close()
        with open('/sentence_wise_normalised_ip_to_tagger/sentence_ip_to_tagger_'+fnum+'.txt','r') as f:
            content1=f.readlines()
        f.close()
    except:
        continue
    try:
        with open("/sentence_wise_normalised_op_xml/tagger_op_"+fnum+".xml", "r") as file:
            content2 = file.readlines()
            content2 = "".join(content2)
            bs_content = bs(content2, "lxml")
        file.close()
    except:
        continue
        
    other=bs_content.find_all("sentence")
    
    for itr in range(len(content)):
        content[itr]=content[itr].replace('\n','')
        res=(predictor.predict(sentence=content[itr]))
        d={'chem_tag_mol':'','chem_tag_quan':'','v':'','arg0':'','arg1':'','arg2':'','sentence':'','mol':'','proc':'','quan':'','condns':''}
        
        mol_list=[]
        quan_list=[]
        molecules=other[itr].find_all("molecule")

       
        for m in molecules:
            mol=m.find_all("oscarcm")
            mol=re.sub("</?oscar-?cm>",' ',str(mol))
            mol=str(mol).replace(']','')
            mol=str(mol).replace('[','')
            mol_list.append(mol)

        quan=m.find_all("quantity")
        quan=re.sub("</?[A-z-_ =\"]*>",' ',str(quan))
        quan=str(quan).replace(']','')
        quan=str(quan).replace('[','')
        quan_list.append(quan)
            
       
        d['chem_tag_mol']='|'.join(mol_list)
        d['chem_tag_quan']='|'.join(quan_list)
            
        
        
        d['sentence']=content[itr]
        arg1=[]
        arg0=[]
        arg2=[]
        v=[]
        for i in res['verbs']:            
            s=((i['description']))
            if 'ARG1:' in s:
                j=s.index('ARG1: ')
                j=j+6
                a=''
                while(s[j]!=']'):
                    a=a+s[j]
                    j=j+1
                if len(a.split(' '))<2:
                    arg1.append('')
                    f=1
                    
                if len(a.split(' '))>2:
                    text_tok = nltk.word_tokenize(a)
                    pos_tagged = nltk.pos_tag(text_tok)
                    for word,word_class in pos_tagged:
                        if word_class == 'IN':
                            f=1
                            arg1.append(a)
                            break 
                if f==0:
                    arg1.append('')

            if 'ARG0:' in s:
                j=s.index('ARG0: ')
                j=j+6
                a=''
                while(s[j]!=']'):
                    a=a+s[j]
                    j=j+1
                f=0
                if len(a.split(' '))<2:
                    arg0.append('')
                    f=1
                   
                    
                if len(a.split(' '))>2:
                    text_tok = nltk.word_tokenize(a)
                    pos_tagged = nltk.pos_tag(text_tok)
                    for word,word_class in pos_tagged:
                        if word_class == 'IN':
                            f=1
                            arg0.append(a)
                            break 
                if f==0:
                    arg0.append('')
            
          
            if 'V:' in s:
                j=s.index('V: ')
                j=j+3
                a=''
                while(s[j]!=']'):
                    a=a+s[j]
                    j=j+1
              
                v.append(a)
              

            if 'ARG2:' in s:
                j=s.index('ARG2: ')
                j=j+6
                a=''
                while(s[j]!=']'):
                    a=a+s[j]
                    j=j+1
              
                if len(a.split(' '))<2:
                    arg2.append('')
                    f=1
                
                    
                if len(a.split(' '))>2:
                    text_tok = nltk.word_tokenize(a)
                    pos_tagged = nltk.pos_tag(text_tok)
                    for word,word_class in pos_tagged:
                        if word_class == 'IN':
                            f=1
                            arg2.append(a)
                            break 
                if f==0:
                    arg2.append('')
                    
        d['v']='|'.join(v)
        d['arg0']='|'.join(arg0)
        d['arg1']='|'.join(arg1)
        d['arg2']='|'.join(arg2)
        
        mol_list=[]
        proc_list=[]
        quan_list=[]
       
        try:
            quants = parser.parse(content1[itr])
            #print(quants)
            for q in range(len(quants)):
                quan_list.append(str(quants[q].surface))
                # print(quants[j].surface)
            d['quan']='|'.join((quan_list))
        except:
            pass

        content1[itr]=content1[itr].replace('\n','')
        doc=Document(content1[itr])
        for p in range(len(doc.cems)):
           
            results = pcp.get_compounds(str(doc.cems[p]), 'name')
            if results!='':
                mol_list.append(str(doc.cems[p]))
        d['mol']='|'.join(mol_list)


        for proc in processes:
            if proc in content1[itr].lower():
                proc_list.append(proc)
        d['proc']='|'.join(proc_list)
     
        
        
        
        l=d['quan'].split('|')
#         
        extracted_quan=[]
        condns=[]
        for j in l:
            if j == 'nan':
               
                extracted_quan.append(' ')
                condns.append(' ')
                continue
            f=0
            if (num_units.match(j))!=None:
                f=1
               
                extracted_quan.append(str(num_units.match(j).groups(1)))


            if (decnum_units.match(j))!=None:
                f=1
              
                extracted_quan.append(str(decnum_units.match(j).groups(1)))


            if (unit_sq.match(j))!=None:
                f=1
              
                extracted_quan.append(str(unit_sq.match(j).groups(1)))


            if (plus_minus.match(j))!=None:
                f=1
                
                extracted_quan.append(str(plus_minus.match(j).groups()))


            if (numxnum.match(j))!=None:
                f=1
              
                extracted_quan.append(str(numxnum.match(j).groups()))

            if conditions.match(j)!=None:
                condns.append(str(conditions.match(j).groups()))



#
        for e in range(len(extracted_quan)):
#            
            if len(extracted_quan[e])>4:
                extracted_quan[e]=extracted_quan[e].split(',')[0].replace('(','').replace('\'','')
        
        for e in range(len(condns)):
            if len(condns[e])>4:
                condns[e]=condns[e].split(',')[0].replace('(','').replace('\'','')
                

        l=d['quan'].split('|')
        sent=(d['sentence'])
       
        extracted_quan1=[]
        condns1=[]

        for j in range(len(l)):
            if l[j] == 'nan':
                extracted_quan1.append(' ')
                condns1.append(' ')
                continue
         
            f=0
           
            numbers=[]
            f=0
            if re.search('[a-zA-Z]', l[j])==None:
                try:
                    n=(num_.search(l[j]).groups())
                   
                    if n[0] in sent:
                        
                        p=sent.index(n[0])
                       
                        if (num_units_.match(sent[p:p+10]))!=None:
                            f=1
                            extracted_quan1.append(str(num_units_.match(sent[p:p+10]).groups(1)))


                        if (unit_sq_.match(sent[p:p+10]))!=None:
                            f=1
                            extracted_quan1.append(str(unit_sq_.match(sent[p:p+10]).groups(1)))


                        if (plus_minus_.match(sent[p:p+10]))!=None:
                            f=1
                            extracted_quan1.append(str(plus_minus_.match(sent[p:p+10]).groups()))


                        if (numxnum_.match(sent[p:p+10]))!=None:
                            f=1
                            extracted_quan1.append(str(numxnum_.match(sent[p:p+10]).groups()))

                        if conditions_.match(sent[p:p+10])!=None:
                           
                            condns1.append(str(conditions_.match(sent[p:p+10]).groups()))

                        if conditions_plus_minus_.match(sent[p:p+10])!=None:
                            condns1.append(str(conditions_plus_minus_.match(sent[p:p+10]).groups()))

                except:
                    continue

        for e in range(len(extracted_quan1)):
            print(type(extracted_quan1[e]))
            if len(extracted_quan1[e])>4:
                extracted_quan1[e]=extracted_quan1[e].split(',')[0].replace('(','').replace('\'','')
        
        for e in range(len(condns1)):
            if len(condns1[e])>4:
                condns1[e]=condns1[e].split(',')[0].replace('(','').replace('\'','')
    

        d['quan']='|'.join(extracted_quan)+'|'+'|'.join(extracted_quan1)
        d['condns']='|'.join(condns)+'|'+'|'.join(condns1)

    
        csv_columns = ['chem_tag_mol','chem_tag_quan','v','arg0','arg1','arg2','sentence','mol','proc','quan','condns']
        try:
            with open('/amcpe_mw/amcpe_mpq'+fnum+'.csv', 'a') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
                writer.writerow(d)
        except IOError:
            print("I/O error")

            